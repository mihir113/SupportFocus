# SupportFocus

**This add-on will be used for inter company distribution. This is not a public add-on **

## What it does

This extension just includes:

* view.js makes API calls to internal intranet sites with information entered by user. This allows the user to update the internal portal without the need to navigate to the actual site. The JS is also used to orchestrate visibility of the fields on the UI as we are using pure Javascript and no additional libraries.