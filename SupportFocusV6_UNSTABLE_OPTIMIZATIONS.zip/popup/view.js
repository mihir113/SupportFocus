//Global Variables-Start
(function() {
  'use strict';
  // this function is strict...
}());
var status_open = "Y";
var srNumber = "";
var status_new = "N";
var proj_available = "Y";
var getSR = "";
var updateSR = "";
var createSR = "";
var getProject = "";
//Global Variables-End
getURL();//Initialize URL variables
function errorToggle() {

  document.getElementById("form_container").style.display = "none";
  document.getElementById("error_content").style.display = "block";
}
//When the Firefox Addon is loaded 
window.addEventListener("load", populateSRNumber);
function populateSRNumber() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("csiDiv").style.display = "none";
  document.getElementById("srSummary").style.display = "none";
  document.getElementById("lblSRClose1").style.display = "none";
  browser.tabs.query({
    active: true,
    currentWindow: true
  }).then(function(tabs) {
    var currentTabUrl = tabs[0].url;
    var url = new URL(currentTabUrl);
    var domain = url.hostname;
    if (domain === ("support.us.oracle.com")) { //Execute the rest of the plugin code only when user is MOS site
      srNumber = url.searchParams.get("srNumber");
      var inputBoxSRNum = document.getElementById("element_1"); // Set the SR Number Parameter to the SR Input Textbox on form.
      inputBoxSRNum.value = srNumber;
      if (srNumber !== "") {
		  getURL();
        getSRUpdate();
      }
    } else { //Error Handling
      document.getElementById("form_container").style.display = "none";
      document.getElementById("error_content").style.display = "block"; //Display Error Message
    }
  });
  document.getElementById("element_3_1").checked = true; //Set the Status to be Open by Default	
}
//Function to fetch existing SR Update
function getSRUpdate() {
  var url = getSR + srNumber;
  const xhr = new XMLHttpRequest();
  xhr.timeout = 2000;
  xhr.onreadystatechange = function(e) {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var responseText = JSON.parse(xhr.responseText);
        var srCount = Object.keys(responseText.items).length;
        if (srCount > 0) { //SR exists in Portal
          var isSROpenInPortal = responseText.items[0].is_open;
          var portalUpdate = responseText.items[0].issue_detail;
          // If SR Is Open
          if (isSROpenInPortal === "Y") {
            document.getElementById("element_3_1").checked = true;
            document.getElementById("element_3_2").checked = false;
          } else {
            document.getElementById("element_3_1").checked = false;
            document.getElementById("element_3_2").checked = true;
          }
          if (portalUpdate !== "") {
            document.getElementById("element_2").value = portalUpdate.replace(/<br ?\/?>/g, "\n"); //Replacing Breaks with JS equivalent
          }
        } else { //No SR Found in Portal, simulating new SR flow
          document.getElementById("element_3_1").checked = false;
          document.getElementById("element_3_2").checked = false;
          document.getElementById("element_3_3").checked = true;
          document.getElementById("csiDiv").style.display = "block";
          document.getElementById("srSummary").style.display = "block";
          document.getElementById("projDiv").style.display = "None";
          status_open = "N";
          status_new = "Y";
        }
      } else {
        window.alert("Error fetching existing SR!");
      }
    }
  };
  xhr.ontimeout = function() {
    window.alert("Well, that took too long, try again. Admins are notified");
  };
  xhr.open("get", url, true);
  xhr.send();
}
//Code to toggle when CLOSED Checkbox is checked
document.addEventListener("DOMContentLoaded", function(event) {
  var _selector = document.querySelector("input[name=element_3_2]");
  _selector.addEventListener("change", function(event) {
    if (_selector.checked) {
      document.getElementById("element_3_1").checked = false;
      document.getElementById("element_3_3").checked = false;
      document.getElementById("csiDiv").style.display = "None";
      document.getElementById("projDiv").style.display = "None";
      document.getElementById("srSummary").style.display = "none";
      document.getElementById("lblSRUpd1").style.display = "none";
      document.getElementById("lblSRClose1").style.display = "block";
      status_open = "N";
    }
  });
});
//Code to toggle when OPEN Checkbox is checked
document.addEventListener("DOMContentLoaded", function(event) {
  var _selector = document.querySelector("input[name=element_3_1]");
  _selector.addEventListener("change", function(event) {
    if (_selector.checked) {
      document.getElementById("element_3_2").checked = false;
      document.getElementById("element_3_3").checked = false;
      document.getElementById("csiDiv").style.display = "None";
      document.getElementById("projDiv").style.display = "None";
      document.getElementById("srSummary").style.display = "none";
      document.getElementById("lblSRClose1").style.display = "none";
      document.getElementById("lblSRUpd1").style.display = "block";
      status_open = "Y";
      status_new = "N";
    }
  });
});
//Code to toggle when NEW- Checkbox is checked
document.addEventListener("DOMContentLoaded", function(event) {
  var _selector = document.querySelector("input[name=element_3_3]");
  _selector.addEventListener("change", function(event) {
    if (_selector.checked) {
      document.getElementById("element_3_1").checked = false;
      document.getElementById("element_3_2").checked = false;
      document.getElementById("csiDiv").style.display = "block";
      document.getElementById("srSummary").style.display = "block";
      document.getElementById("projDiv").style.display = "None";
      document.getElementById("lblSRClose1").style.display = "none";
      document.getElementById("lblSRUpd1").style.display = "block";
      status_open = "N";
      status_new = "Y";
    }
  });
});
document.addEventListener("DOMContentLoaded", function(event) {
  document.getElementById("getProjectDetails").addEventListener("click", function() {
    if (document.getElementById("csiNumber").value !== '') {
      getProjectDetails(); //Invoke call to fetch Project Name
    } else {
      window.alert("Provide a CSI Number");
    }
  });
});
document.addEventListener("submit", (e) => { //When Firefox addon is submit 
  document.getElementById("form_container").style.display = "none";
  document.getElementById("loader").style.display = "block";
  if (document.getElementById("element_2").value !== "") {
    if (status_new == "Y" && proj_available == "N") {
      window.alert("Required - Valid Project Name");
    }
    //If SR is OPEN
    if (status_open == "Y" && status_new == "N") {
      var srNum = document.getElementById("element_1").value;
      var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
      var invocation = new XMLHttpRequest();
      var url = updateSR;
      if (invocation) {
        invocation.open("POST", url, true);
        invocation.timeout = 5000;
        invocation.setRequestHeader("sr_number", srNum); //Send SR Number
        invocation.setRequestHeader("comment", srUpdate); //Send the SR Update
        invocation.setRequestHeader("is_open", status_open); //Send the Status of the SR
        invocation.withCredentials = true;
        invocation.send();
        invocation.onreadystatechange = function(e) {
          if (invocation.readyState === 4) {
            if (invocation.status === 200) {
              document.getElementById("loader").style.display = "none";
              document.getElementById("form_container").style.display = "block";
              window.alert("SR Updated In Portal");
              window.close(); //Close the popup
            }
          }
        };
      }
    }
    //If SR is Closed
    if (status_open == "N" && status_new == "N") {
      var srNum = document.getElementById("element_1").value;
      var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
      var invocation = new XMLHttpRequest();
      var url = updateSR;
      if (invocation) {
        invocation.open("POST", url, true);
        invocation.timeout = 5000;
        invocation.setRequestHeader("sr_number", srNum); //Send SR Number
        invocation.setRequestHeader("comment", srUpdate); //Send the SR Update
        invocation.setRequestHeader("is_open", status_open); //Send the Status of the SR
        invocation.withCredentials = true;
        invocation.send();
        invocation.onreadystatechange = function(e) {
          if (invocation.readyState === 4) {
            if (invocation.status === 200) {
              document.getElementById("loader").style.display = "none";
              document.getElementById("form_container").style.display = "block";
              window.alert("SR Closed In Portal");
              window.close(); //Close the popup
            }
          }
        };
      }
    }
    //If SR is a NEW SR
    if (status_open == "N" && status_new == "Y" && proj_available == "Y") {
      var srSummary = document.getElementById("element_Summary").value;
      var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
      var srNum = document.getElementById("element_1").value;
      var projectName = document.getElementById("projName").value;
      var invocation = new XMLHttpRequest();
      var url = createSR;
      if (invocation) {
        invocation.open("POST", url, true);
        invocation.timeout = 5000;
        invocation.setRequestHeader("project", projectName); //Set Project Name
        invocation.setRequestHeader("sr_number", srNum); //Set the SR Number
        invocation.setRequestHeader("summary", srSummary); //Set the SR Update
        invocation.setRequestHeader("is_open", "Y"); //Set the SR open in Portal
        invocation.setRequestHeader("comments", srUpdate); //Set SR Summary
        invocation.withCredentials = true;
        invocation.send();
        invocation.onreadystatechange = function(e) {
          if (invocation.readyState === 4) {
            if (invocation.status === 200) {
              document.getElementById("loader").style.display = "none";
              document.getElementById("form_container").style.display = "block";
              window.alert("SR Created In Portal");
              window.close(); //Close the popup
            }
          }
        };
      }
    }
  } //If end
  else {
    window.alert("Please provide an update before clicking Submit");
  }
  e.preventDefault(); // Stop the OnLoad function to execute on Submit.
});
//Function to fetch Project Name
function getProjectDetails() {
  var csiNumber = document.getElementById("csiNumber").value.trim(); //Remove whitespaces if any
  var url = getProject + csiNumber;
  const xhr = new XMLHttpRequest();
  xhr.timeout = 5000;
  xhr.onreadystatechange = function(e) {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var responseText = JSON.parse(xhr.responseText);
        var countOfProjects = Object.keys(responseText.items).length;
        if (projName !== "") {
          document.getElementById("csiTooltip").style.display = "none";
          document.getElementById("projDiv").style.display = "block";
          if (countOfProjects > 0) {
            var catOptions = "";
            for (var i = 0; i < countOfProjects; i++) {
              var option = document.createElement("option");
              option.text = responseText.items[i].projectname;
              option.value = responseText.items[i].projectid;
              option.selected = "selected";
              var select = document.getElementById("projName");
              select.appendChild(option);
            }
          } else {
            proj_available = "N";
            window.alert("No projects available, Please Register the customer in Implementation Portal");
          }
        }
      } else {
        window.alert("Error, please try again");
      }
    }
  };
  xhr.ontimeout = function() {
    window.alert("Well, that took too long, please try again.");
  };
  xhr.open("get", url, true);
  xhr.send();
}
//Retrieve the Endpoints
function getURL() {
  var xhr = new XMLHttpRequest()
  xhr.open("GET", browser.extension.getURL('/popup/url.json'), true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        var responseText = JSON.parse(xhr.responseText);
        getSR = responseText.getSR;
        updateSR = responseText.updateSR;
        createSR = responseText.createSR;
        getProject = responseText.getProject;
      } else {
        alert("Error Loading URL, Please Retry");
      }
    }
  }
  xhr.send();
}